import { Component } from '@angular/core';

@Component({
  selector: 'app-testingcomponent',
  templateUrl: './testingcomponent.component.html',
  styleUrls: ['./testingcomponent.component.css']
})
export class TestingcomponentComponent {

}
